shiboken_library_soversion = str(5.15)

version = "5.15.0"
version_info = (5, 15, 0, "", "")

__build_date__ = '2020-06-18T12:21:12+00:00'




__setup_py_package_version__ = '5.15.0'
